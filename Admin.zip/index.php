<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="Css/bootstrap.min.css">
    <!-- Font Awesome  CSS-->
    <link rel="stylesheet" href="Css/all.min.css">
    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
    <!-- Custom CSS-->
    <link rel="stylesheet" href="Css/custom.css">
    
    
    <title>GSMS</title>
</head>
<body>
    
<!-- start Navigation-->
<nav class="navbar navbar-expand-sm navbar-dark bg-info pl-5 fixed-top">
  <a href="index.php" class="navbar-brand text-light ">TechTune Motors</a>
  <span class="navbar-text colorful-text ">We Keep Your Wheels turning</span>
  <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#myMenu">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="myMenu">
    <ul class="navbar-nav pl-5 custom-nav">
        <li class="nav-item"><a href="index.php" class="nav-link">Home</a> </li>
        <li class="nav-item"><a href="#Services" class="nav-link">Services</a> </li>
        <li class="nav-item"><a href="#registration" class="nav-link">registration</a> </li>
        <li class="nav-item"><a href="User/userLogin.php" class="nav-link">Login</a> </li>
        <li class="nav-item"><a href="#Contact" class="nav-link">Contact</a> </li>      
</ul>
</nav>  <!-- end Navigation --> 



<!-- Start Header Jumbotron-->
<!-- <header class="jumbotron back-image" style="background-image:url(images/Banner.jpg);"> -->
<header class="jumbotron back-image" style="background-image:url(images/homePage.jpg);">
<div class="myclass mainHeading">
   <h1 class="text-uppercase text-warning font-weight-bold text-center">  </h1>
   <p class="font-italic text-warning text-center text-right">We Keep Your Wheels Turning</p>
 
   <a href="User/userLogin.php" class="btn btn-success mr-4">Login</a>
   <a href="#registration" class="btn btn-danger mr-4">Sign Up</a>
</header><!-- End Header Jumbotron-->  
<!-- Start Introducion Section -->
<div class="container">
    <div class="jumbotron bg-light border rounded">
        <h3 class="text-center"> TechTune Motor Services</h3>
        <p>
        At TechTune Motors, excellence is our commitment. Our website offers effortless access to vital information and streamlined appointment booking, ensuring a seamless experience. Trust us for all your automotive needs, and we'll keep your vehicle operating at peak performance. Our certified technicians, state-of-the-art facilities, transparent pricing, and dedication to customer satisfaction set us apart. We're not just a garage; we're a community-oriented, environmentally conscious team dedicated to your vehicle's well-being. Choose TechTune Motors for quality service and peace of mind, knowing your vehicle is in expert hands.
</p>
</div>
</div><!-- End Introducion Section -->

<!-- Start Services section-->
<div class="container text-center border-bottom" id="Services">
    <h2> Our Services</h2>
    <div class="row mt-4">
        <div class="col-sm-4 mb-4">
        <a href="#"><i class="fas fa-car fa-8x text-success"></i></a>
        <h4 class="mt-4"> 4-Wheeler </h4>
    </div>
    <div class="col-sm-4 mb-4">
        <a href="#"><i class="fas fa-sliders-h fa-8x text-primary"></i></a>
        <h4 class="mt-4">Premitive Maintenance</h4>
    </div>
        <div class="col-sm-4 mb-4">
        <a href="#"><i class="fas fa-cogs fa-8x text-info"></i></a>
        <h4 class="mt-4"> Fault Repair </h4>
    </div>
</div>
</div><!-- End Services section-->

<!-- Start Registration Form section-->
<?php include('userRegistration.php') ?>
<!-- End Registration Form section-->
<!-- Start Happy Customer -->
<div class="jumbotron bg-secondary">
   <div class="container">
    <h2 class="text-center text-dark"> Happy Customers </h2>
    <div class="row mt-5">
        <div class="col-lg-3 col-sm-6">
            <div class="card bg-light mb-2">
               <div class="card-body text-center">
                <img src="images/veer.jpg" class="img-fluid" style="border-radius:100px;" alt="img">
                <h4 class="card-title text-dark">Veer </h4>
                <p class="card-text text-dark custom-font">Outstanding service! TechTune Motors is reliable, efficient, and trustworthy. They've consistently kept my vehicle in top shape, earning my trust and loyalty.</p>
               </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6">
            <div class="card bg-light mb-2">
               <div class="card-body text-center">
                <img src="images/p2.jpg" class="img-fluid" style="border-radius:100px;" alt="img">
                <h4 class="card-title text-dark">Smriti Verma</h4>
                <p class="card-text text-dark">TechTune Motors is the best in the business. Their skilled team and user-friendly website simplify the car care process. A true gem for automotive services.</p>
               </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6">
            <div class="card bg-light mb-2">
               <div class="card-body text-center">
                <img src="images/p3.png" class="img-fluid" style="border-radius:100px;" alt="img">
                <h4 class="card-title text-dark">Subham K</h4>
                <p class="card-text text-dark">I've never had a more seamless experience with an auto service provider. TechTune Motors' dedication to excellence and professionalism shine through in every interaction.</p>
               </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6">
            <div class="card bg-light mb-2">
               <div class="card-body text-center">
                <img src="images/p4.jpg" class="img-fluid" style="border-radius:100px;" alt="img">
                <h4 class="card-title text-dark">Mayank Dugar</h4>
                <p class="card-text text-dark">Exceptional quality and convenience that's what TechTune Motors offers. Their website's ease of use and their team's expertise make vehicle maintenance a breeze. Highly recommended!</p>
               </div>
            </div>
        </div>
    </div> 
  </div><!-- End Happy Customer -->


</div>
<!-- Start Contact Us -->
<div class="container" id="Contact">
    <h2 class="text-center mb-4"> Contact Us</h2>
    <div class="row">
    <!-- start 1st column-->
    <?php include('contactForm.php') ?>
    <!-- End of 1st column-->
    <div class="col-md-4 text-center"><!-- start 2nd column-->
    <strong>Headquarter:</strong><br>
    TechTune Motors,<br>
    RR Nagar,Bengaluru<br>
    <a href="#" target="_blank"> www.techtunemotors.com</a><br>
    <br>
    <br>
    <strong>C0-Partner:</strong><br>
    Varcons Technologies Pvt Ltd<br>
    MG road,Bengaluru<br>
    <a href="#" target="_blank"> https://www.varconstech.com/</a><br>
    <br>
    <br>
</div>  
</div>
</div>
<footer class="container-fluid bg-dark mt-5 text-white">
    <div class="container">
        <div class="row py-3">
            <div class="col-md-6"> <!-- start 1st column-->
            <span class="pr-2">Follow Us: </span>
            <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-facebook-f"></i></a> <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-twitter"></i></a> <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-youtube"></i></a> <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-google-plus-g"></i></a> <a href="#" target="_blank" class="pr-2 fi-color"><i class="fas fa-rss"></i></a></div><!--- End 1st Column-->
            <div class="col-md-6 d-flex justify-content-end"><!-- Start of 2nd Column -->
    <small>Designed by R.K Chandra &copy; 2023</small>
    <small class="ml-2"><a href="Admin/login.php">Admin Login</a></small>
</div>
<!--- End of 2nd Column-->
</div>
</div>
</footer>
<!-- JavaScript-->
<script src="js/jquery.min.js"> </script>
<script src="js/popper.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
<script src="js/all.min.js"> </script>
</body>
</html>